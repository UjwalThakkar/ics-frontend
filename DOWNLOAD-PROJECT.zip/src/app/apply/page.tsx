'use client'

import React, { useState, useEffect, Suspense } from 'react'
import { useSearchParams } from 'next/navigation'
import {
  FileText,
  Globe,
  Users,
  Award,
  BookOpen,
  Shield,
  ArrowRight,
  Clock,
  DollarSign,
  AlertCircle
} from 'lucide-react'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import WhatsAppWidget from '@/components/WhatsAppWidget'
import ApplicationForm from '@/components/ApplicationForm'

interface ApplicationFormData {
  firstName: string
  lastName: string
  dateOfBirth: string
  placeOfBirth: string
  nationality: string
  gender: string
  maritalStatus: string
  email: string
  phone: string
  address: string
  city: string
  country: string
  postalCode: string
  serviceType: string
  urgency: string
  previousApplications: string
  uploadedDocuments: Array<{
    name: string
    size: number
    type: string
    file: File
  }>
}

function ApplyPageContent() {
  const [selectedService, setSelectedService] = useState<string | null>(null)
  const searchParams = useSearchParams()

  useEffect(() => {
    try {
      const serviceParam = searchParams.get('service')
      if (serviceParam) {
        setSelectedService(serviceParam)
      }
    } catch (error) {
      // Handle static export errors gracefully
      console.log('Service parameter not available in static mode')
    }
  }, [searchParams])

  const services = [
    {
      id: 'passport-reissue',
      category: 'Passport Services',
      title: 'Passport Re-issue (Lost/Stolen)',
      description: 'Apply for passport re-issue if your passport is lost, stolen, or damaged',
      icon: <BookOpen className="h-8 w-8" />,
      color: 'bg-blue-500',
      processingTime: '5-7 days',
      fee: 'R 1,200',
      documents: [
        'Police report for lost/stolen passport',
        'Proof of Indian origin',
        '2 passport size photographs',
        'Application form'
      ]
    },
    {
      id: 'passport-minor',
      category: 'Passport Services',
      title: 'Passport Re-issue (Minor Child)',
      description: 'Apply for minor child passport re-issue',
      icon: <BookOpen className="h-8 w-8" />,
      color: 'bg-blue-500',
      processingTime: '5-7 days',
      fee: 'R 1,200',
      documents: [
        'Birth certificate',
        'Parents passport copies',
        '2 passport size photographs',
        'NOC from other parent'
      ]
    },
    {
      id: 'oci-new',
      category: 'OCI Services',
      title: 'New OCI Application',
      description: 'Apply for Overseas Citizen of India card',
      icon: <Users className="h-8 w-8" />,
      color: 'bg-purple-500',
      processingTime: '8-12 weeks',
      fee: 'R 2,500',
      documents: [
        'Current passport',
        'Proof of Indian origin',
        'Address proof',
        '2 passport size photographs'
      ]
    },
    {
      id: 'visa-tourist',
      category: 'Visa Services',
      title: 'Tourist Visa',
      description: 'Apply for Indian tourist visa',
      icon: <Globe className="h-8 w-8" />,
      color: 'bg-green-500',
      processingTime: '7-15 days',
      fee: 'Variable',
      documents: [
        'Valid passport',
        'Visa application form',
        '2 passport size photographs',
        'Travel itinerary'
      ]
    },
    {
      id: 'attestation-academic',
      category: 'Document Attestation',
      title: 'Academic Degree Attestation',
      description: 'Attest your academic certificates',
      icon: <Award className="h-8 w-8" />,
      color: 'bg-orange-500',
      processingTime: '5 days',
      fee: 'R 500',
      documents: [
        'Original degree certificate',
        'University transcript',
        '2 sets of attested copies',
        'Passport copy'
      ]
    },
    {
      id: 'emergency-certificate',
      category: 'Emergency Services',
      title: 'Emergency Certificate',
      description: 'Emergency travel document for urgent travel',
      icon: <Shield className="h-8 w-8" />,
      color: 'bg-red-500',
      processingTime: '1-2 days',
      fee: 'R 800',
      documents: [
        'Police report',
        'Travel tickets',
        'Proof of emergency',
        '2 passport size photographs'
      ]
    }
  ]

  const handleServiceSelect = (serviceId: string) => {
    setSelectedService(serviceId)
  }

  const handleFormSubmit = (formData: ApplicationFormData) => {
    alert('Application submitted successfully! Reference: ICS2025001234')
    console.log('Form data:', formData)
  }

  const handleFormSave = (formData: ApplicationFormData) => {
    alert('Application saved as draft!')
    console.log('Saved form data:', formData)
  }

  if (selectedService) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="mb-6">
            <button
              onClick={() => setSelectedService(null)}
              className="text-blue-600 hover:text-blue-800 flex items-center"
            >
              ← Back to Service Selection
            </button>
          </div>
          <ApplicationForm
            serviceType={selectedService}
            onSubmit={handleFormSubmit}
            onSave={handleFormSave}
          />
        </div>
        <Footer />
        <WhatsAppWidget />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <div className="container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-navy mb-4">
            Apply for <span className="text-saffron">Consular Services</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Select the service you wish to apply for. All applications require in-person submission
            with original documents and attested copies.
          </p>
        </div>

        {/* Important Notice */}
        <div className="bg-yellow-50 border-l-4 border-yellow-400 p-6 mb-8 rounded-r-lg">
          <div className="flex">
            <AlertCircle className="h-6 w-6 text-yellow-400 mr-3 mt-0.5" />
            <div>
              <h3 className="text-lg font-medium text-yellow-800 mb-2">Application Requirements</h3>
              <ul className="text-sm text-yellow-700 space-y-1">
                <li>• All applications must be submitted in person</li>
                <li>• Bring original documents + 2 sets of attested copies from Commissioner of Oaths</li>
                <li>• Submission: 9:30 AM - 12:30 PM | Collection: 3:00 PM - 4:30 PM</li>
                <li>• Book appointment in advance to avoid waiting</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => (
            <div
              key={service.id}
              className="bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
            >
              {/* Service Header */}
              <div className={`${service.color} text-white p-6`}>
                <div className="flex items-center justify-between mb-4">
                  <div className="bg-white/20 p-3 rounded-lg">
                    {service.icon}
                  </div>
                  <div className="text-right">
                    <div className="text-sm opacity-90">Processing Time</div>
                    <div className="font-semibold">{service.processingTime}</div>
                  </div>
                </div>
                <h3 className="text-xl font-bold mb-2">{service.title}</h3>
                <p className="text-sm opacity-90">{service.category}</p>
              </div>

              {/* Service Content */}
              <div className="p-6">
                <p className="text-gray-600 mb-4">{service.description}</p>

                {/* Service Details */}
                <div className="space-y-3 mb-6">
                  <div className="flex items-center justify-between text-sm">
                    <span className="flex items-center text-gray-600">
                      <Clock className="h-4 w-4 mr-2" />
                      Processing
                    </span>
                    <span className="font-medium">{service.processingTime}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="flex items-center text-gray-600">
                      <DollarSign className="h-4 w-4 mr-2" />
                      Fee
                    </span>
                    <span className="font-medium">{service.fee}</span>
                  </div>
                </div>

                {/* Required Documents */}
                <div className="mb-6">
                  <h4 className="font-medium text-gray-800 mb-2">Required Documents:</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    {service.documents.map((doc, index) => (
                      <li key={index} className="flex items-start">
                        <span className="text-green-500 mr-2 mt-0.5">•</span>
                        {doc}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Action Button */}
                <button
                  onClick={() => handleServiceSelect(service.id)}
                  className={`w-full ${service.color} text-white py-3 rounded-lg font-semibold flex items-center justify-center hover:opacity-90 transition-opacity`}
                >
                  Apply Now
                  <ArrowRight className="h-4 w-4 ml-2" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Process Steps */}
        <div className="mt-16 bg-white rounded-xl shadow-lg p-8">
          <h2 className="text-2xl font-bold text-navy text-center mb-8">
            Application <span className="text-saffron">Process</span>
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
            {[
              {
                step: '1',
                title: 'Select Service',
                description: 'Choose your required consular service',
                icon: <FileText className="h-6 w-6" />
              },
              {
                step: '2',
                title: 'Fill Application',
                description: 'Complete the online application form',
                icon: <FileText className="h-6 w-6" />
              },
              {
                step: '3',
                title: 'Book Appointment',
                description: 'Schedule your document submission',
                icon: <Clock className="h-6 w-6" />
              },
              {
                step: '4',
                title: 'Submit Documents',
                description: 'Visit consulate with required documents',
                icon: <FileText className="h-6 w-6" />
              },
              {
                step: '5',
                title: 'Track & Collect',
                description: 'Track status and collect documents',
                icon: <Shield className="h-6 w-6" />
              }
            ].map((item, index) => (
              <div key={index} className="text-center relative">
                {index < 4 && (
                  <div className="hidden md:block absolute top-8 left-full w-full h-0.5 bg-gradient-to-r from-saffron to-orange-400 z-0"></div>
                )}
                <div className="relative z-10">
                  <div className="w-16 h-16 bg-saffron text-white rounded-full flex items-center justify-center font-bold text-lg mx-auto mb-4 shadow-lg">
                    {item.step}
                  </div>
                  <h4 className="font-semibold text-navy mb-2">{item.title}</h4>
                  <p className="text-sm text-gray-600">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Help Section */}
        <div className="mt-12 bg-blue-50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-blue-800 mb-4">Need Help?</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                <FileText className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <h4 className="font-medium text-blue-800">Document Checklist</h4>
                <p className="text-sm text-blue-600">Download required document lists</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                <Clock className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <h4 className="font-medium text-blue-800">Processing Times</h4>
                <p className="text-sm text-blue-600">Check current processing times</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                <Shield className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <h4 className="font-medium text-blue-800">Support</h4>
                <p className="text-sm text-blue-600">Contact our support team</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
      <WhatsAppWidget />
    </div>
  )
}

export default function ApplyPage() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <ApplyPageContent />
    </Suspense>
  )
}
