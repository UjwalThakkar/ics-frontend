'use client'

import React from 'react'

interface IndianEmblemProps {
  size?: 'sm' | 'md' | 'lg' | 'xl'
  className?: string
}

const IndianEmblem: React.FC<IndianEmblemProps> = ({ size = 'md', className = '' }) => {
  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-12 h-12',
    lg: 'w-16 h-16',
    xl: 'w-20 h-20'
  }

  return (
    <div className={`${sizeClasses[size]} ${className} relative`}>
      {/* Official Indian National Emblem - Government of India */}
      <svg
        viewBox="0 0 100 100"
        className="w-full h-full"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Outer Border Circle */}
        <circle cx="50" cy="50" r="48" fill="#000080" stroke="#FFD700" strokeWidth="1"/>

        {/* Inner White Background */}
        <circle cx="50" cy="50" r="44" fill="white"/>

        {/* Lotus Base Platform */}
        <ellipse cx="50" cy="75" rx="35" ry="4" fill="#D4AF37"/>

        {/* Lotus Petals Base */}
        <g transform="translate(50, 73)">
          {Array.from({ length: 8 }, (_, i) => {
            const angle = (i * 45) * Math.PI / 180
            const x = 15 * Math.cos(angle)
            const y = 6 * Math.sin(angle)
            return (
              <ellipse
                key={i}
                cx={x}
                cy={y}
                rx="4"
                ry="8"
                fill="#FFD700"
                transform={`rotate(${i * 45} ${x} ${y})`}
              />
            )
          })}
        </g>

        {/* Three Lions - Ashoka Lions */}

        {/* Central Lion (front facing) */}
        <g transform="translate(50, 50)">
          {/* Lion Body */}
          <ellipse cx="0" cy="8" rx="10" ry="14" fill="#B8860B"/>

          {/* Lion Head */}
          <circle cx="0" cy="-5" r="9" fill="#DAA520"/>

          {/* Mane */}
          <path
            d="M-8 -12 C-10 -20, 10 -20, 8 -12 C8 -6, 6 -2, 0 -2 C-6 -2, -8 -6, -8 -12"
            fill="#8B4513"
          />

          {/* Inner Mane */}
          <circle cx="0" cy="-5" r="6" fill="#DAA520"/>

          {/* Face Features */}
          <circle cx="-3" cy="-7" r="1.5" fill="#000"/>
          <circle cx="3" cy="-7" r="1.5" fill="#000"/>

          {/* Nose and Mouth */}
          <path d="M-1 -3 Q0 -1 1 -3" stroke="#000" strokeWidth="1" fill="none"/>
          <circle cx="0" cy="-4" r="1" fill="#000"/>

          {/* Front Legs */}
          <rect x="-4" y="15" width="3" height="8" fill="#B8860B"/>
          <rect x="1" y="15" width="3" height="8" fill="#B8860B"/>
        </g>

        {/* Left Lion (profile) */}
        <g transform="translate(25, 50) rotate(-30)">
          <ellipse cx="0" cy="8" rx="7" ry="10" fill="#B8860B"/>
          <circle cx="0" cy="-2" r="6" fill="#DAA520"/>
          <path d="M-5 -6 C-7 -12, 5 -12, 3 -6 C3 -3, 1 -1, 0 -1 C-1 -1, -5 -3, -5 -6" fill="#8B4513"/>
          <circle cx="-2" cy="-4" r="1" fill="#000"/>
          <circle cx="1" cy="-4" r="1" fill="#000"/>
        </g>

        {/* Right Lion (profile) */}
        <g transform="translate(75, 50) rotate(30)">
          <ellipse cx="0" cy="8" rx="7" ry="10" fill="#B8860B"/>
          <circle cx="0" cy="-2" r="6" fill="#DAA520"/>
          <path d="M-3 -6 C-5 -12, 7 -12, 5 -6 C5 -3, 1 -1, 0 -1 C-1 -1, -3 -3, -3 -6" fill="#8B4513"/>
          <circle cx="-1" cy="-4" r="1" fill="#000"/>
          <circle cx="2" cy="-4" r="1" fill="#000"/>
        </g>

        {/* Ashoka Chakra (Dharma Wheel) */}
        <g transform="translate(50, 78)">
          <circle cx="0" cy="0" r="8" fill="#000080"/>
          <circle cx="0" cy="0" r="6" fill="white"/>

          {/* 24 Spokes of Dharma Wheel */}
          {Array.from({ length: 24 }, (_, i) => {
            const angle = (i * 15) * Math.PI / 180
            const x1 = 2 * Math.cos(angle)
            const y1 = 2 * Math.sin(angle)
            const x2 = 5.5 * Math.cos(angle)
            const y2 = 5.5 * Math.sin(angle)
            return (
              <line
                key={i}
                x1={x1}
                y1={y1}
                x2={x2}
                y2={y2}
                stroke="#000080"
                strokeWidth="0.4"
              />
            )
          })}

          {/* Center Hub */}
          <circle cx="0" cy="0" r="1.5" fill="#000080"/>
        </g>

        {/* Supporting Animals - Horse and Bull */}

        {/* Left Horse */}
        <g transform="translate(20, 72)">
          <ellipse cx="0" cy="0" rx="8" ry="4" fill="#8B4513"/>
          <circle cx="-5" cy="-3" r="3" fill="#8B4513"/>
          <path d="M-8 -5 L-10 -8 L-7 -6" stroke="#654321" strokeWidth="1" fill="none"/>
          <path d="M-8 -2 L-10 0 L-8 -1" stroke="#654321" strokeWidth="1" fill="none"/>
        </g>

        {/* Right Bull */}
        <g transform="translate(80, 72)">
          <ellipse cx="0" cy="0" rx="8" ry="4" fill="#8B4513"/>
          <circle cx="5" cy="-3" r="3" fill="#8B4513"/>
          <path d="M3 -5 Q6 -8 9 -5" stroke="#654321" strokeWidth="1" fill="none"/>
          <path d="M7 -2 L9 0 L8 -1" stroke="#654321" strokeWidth="1" fill="none"/>
        </g>

        {/* Top Umbrella/Crown */}
        <g transform="translate(50, 25)">
          <ellipse cx="0" cy="0" rx="20" ry="4" fill="#FFD700"/>
          <path d="M-20 0 Q0 -12 20 0" fill="#DAA520"/>
          <circle cx="0" cy="-8" r="3" fill="#FFD700"/>
          <path d="M-3 -8 L0 -12 L3 -8" fill="#B8860B"/>
        </g>

        {/* Satyameva Jayate in Devanagari */}
        <text
          x="50"
          y="92"
          textAnchor="middle"
          fontSize="3.5"
          fill="#000080"
          fontFamily="serif"
          fontWeight="bold"
        >
          सत्यमेव जयते
        </text>

        {/* Decorative Border Pattern */}
        <circle
          cx="50"
          cy="50"
          r="42"
          fill="none"
          stroke="#FFD700"
          strokeWidth="0.5"
          strokeDasharray="1,1"
        />

        {/* Government Seal Text */}
        <text
          x="50"
          y="12"
          textAnchor="middle"
          fontSize="2.5"
          fill="#000080"
          fontFamily="serif"
          fontWeight="bold"
        >
          भारत सरकार
        </text>

        <text
          x="50"
          y="16"
          textAnchor="middle"
          fontSize="2"
          fill="#000080"
          fontFamily="serif"
        >
          GOVERNMENT OF INDIA
        </text>
      </svg>
    </div>
  )
}

export default IndianEmblem
