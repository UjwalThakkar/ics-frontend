'use client'

import React, { useState } from 'react'
import {
  Users,
  FileText,
  Clock,
  CheckCircle,
  XCircle,
  Search,
  Filter,
  Download,
  Mail,
  MessageSquare,
  Phone,
  Settings,
  BarChart3,
  Calendar,
  AlertTriangle,
  Eye,
  Edit,
  Trash2
} from 'lucide-react'

const AdminPanel = () => {
  const [activeTab, setActiveTab] = useState<'applications' | 'users' | 'services' | 'notifications' | 'analytics'>('applications')
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')

  // Mock data
  const applications = [
    {
      id: 'ICS2025001234',
      applicant: 'Raj Patel',
      service: 'Passport Re-issue',
      status: 'pending_review',
      submittedDate: '2025-01-10',
      priority: 'normal',
      documents: 5,
      email: 'raj.patel@email.com',
      phone: '+27 11 234 5678'
    },
    {
      id: 'ICS2025001235',
      applicant: 'Priya Sharma',
      service: 'OCI Application',
      status: 'in_process',
      submittedDate: '2025-01-09',
      priority: 'high',
      documents: 8,
      email: 'priya.sharma@email.com',
      phone: '+27 21 987 6543'
    },
    {
      id: 'ICS2025001236',
      applicant: 'Arjun Singh',
      service: 'Document Attestation',
      status: 'ready_for_collection',
      submittedDate: '2025-01-08',
      priority: 'normal',
      documents: 3,
      email: 'arjun.singh@email.com',
      phone: '+27 31 456 7890'
    }
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending_review': return 'bg-yellow-100 text-yellow-800'
      case 'in_process': return 'bg-blue-100 text-blue-800'
      case 'ready_for_collection': return 'bg-green-100 text-green-800'
      case 'completed': return 'bg-gray-100 text-gray-800'
      case 'rejected': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-600'
      case 'medium': return 'text-orange-600'
      case 'normal': return 'text-green-600'
      default: return 'text-gray-600'
    }
  }

  const updateApplicationStatus = (applicationId: string, newStatus: string) => {
    // This would update the application status in the database
    console.log(`Updating application ${applicationId} to status: ${newStatus}`)
  }

  const sendNotification = (type: 'email' | 'sms' | 'whatsapp', applicationId: string) => {
    console.log(`Sending ${type} notification for application ${applicationId}`)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-navy text-white">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold">Admin Panel</h1>
              <p className="text-blue-200">Consular Services Management System</p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="font-medium">Officer John Smith</p>
                <p className="text-sm text-blue-200">Consular Officer</p>
              </div>
              <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                <Users className="h-6 w-6" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white border-b border-gray-200">
        <div className="container mx-auto px-4">
          <nav className="flex space-x-8">
            {[
              { id: 'applications', label: 'Applications', icon: FileText },
              { id: 'users', label: 'Users', icon: Users },
              { id: 'services', label: 'Services', icon: Settings },
              { id: 'notifications', label: 'Notifications', icon: MessageSquare },
              { id: 'analytics', label: 'Analytics', icon: BarChart3 }
            ].map((tab) => {
              const Icon = tab.icon
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-2 py-4 px-2 border-b-2 transition-colors ${
                    activeTab === tab.id
                      ? 'border-saffron text-saffron'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <Icon className="h-5 w-5" />
                  <span>{tab.label}</span>
                </button>
              )
            })}
          </nav>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-8">
        {activeTab === 'applications' && (
          <div className="space-y-6">
            {/* Filters and Search */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                    <input
                      type="text"
                      placeholder="Search applications by ID, name, or service..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>
                <div className="flex gap-4">
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="all">All Status</option>
                    <option value="pending_review">Pending Review</option>
                    <option value="in_process">In Process</option>
                    <option value="ready_for_collection">Ready for Collection</option>
                    <option value="completed">Completed</option>
                  </select>
                  <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                    <Filter className="h-4 w-4 mr-2" />
                    More Filters
                  </button>
                </div>
              </div>
            </div>

            {/* Applications List */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-lg font-semibold text-gray-800">Applications</h2>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Application
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Applicant
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Service
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Priority
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {applications.map((application) => (
                      <tr key={application.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div>
                            <div className="text-sm font-medium text-gray-900">{application.id}</div>
                            <div className="text-sm text-gray-500">{application.submittedDate}</div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div>
                            <div className="text-sm font-medium text-gray-900">{application.applicant}</div>
                            <div className="text-sm text-gray-500">{application.email}</div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{application.service}</div>
                          <div className="text-sm text-gray-500">{application.documents} documents</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(application.status)}`}>
                            {application.status.replace('_', ' ').toUpperCase()}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`text-sm font-medium ${getPriorityColor(application.priority)}`}>
                            {application.priority.toUpperCase()}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <div className="flex items-center space-x-2">
                            <button
                              className="text-blue-600 hover:text-blue-900 p-1 rounded"
                              title="View Details"
                            >
                              <Eye className="h-4 w-4" />
                            </button>
                            <button
                              className="text-green-600 hover:text-green-900 p-1 rounded"
                              title="Update Status"
                            >
                              <Edit className="h-4 w-4" />
                            </button>
                            <button
                              className="text-purple-600 hover:text-purple-900 p-1 rounded"
                              title="Send Email"
                              onClick={() => sendNotification('email', application.id)}
                            >
                              <Mail className="h-4 w-4" />
                            </button>
                            <button
                              className="text-orange-600 hover:text-orange-900 p-1 rounded"
                              title="Send SMS"
                              onClick={() => sendNotification('sms', application.id)}
                            >
                              <Phone className="h-4 w-4" />
                            </button>
                            <button
                              className="text-indigo-600 hover:text-indigo-900 p-1 rounded"
                              title="Download Documents"
                            >
                              <Download className="h-4 w-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <Clock className="h-8 w-8 text-yellow-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-500">Pending Review</p>
                    <p className="text-2xl font-bold text-gray-900">12</p>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <FileText className="h-8 w-8 text-blue-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-500">In Process</p>
                    <p className="text-2xl font-bold text-gray-900">24</p>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <CheckCircle className="h-8 w-8 text-green-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-500">Ready for Collection</p>
                    <p className="text-2xl font-bold text-gray-900">8</p>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <AlertTriangle className="h-8 w-8 text-red-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-500">Urgent</p>
                    <p className="text-2xl font-bold text-gray-900">3</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'notifications' && (
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h2 className="text-lg font-semibold text-gray-800 mb-4">Send Notifications</h2>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Email Notification */}
                <div className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center mb-3">
                    <Mail className="h-5 w-5 text-blue-600 mr-2" />
                    <h3 className="font-medium">Email Notification</h3>
                  </div>
                  <form className="space-y-3">
                    <select className="w-full p-2 border border-gray-300 rounded">
                      <option>Select Template</option>
                      <option>Application Received</option>
                      <option>Document Required</option>
                      <option>Ready for Collection</option>
                      <option>Application Completed</option>
                    </select>
                    <textarea
                      placeholder="Custom message..."
                      className="w-full p-2 border border-gray-300 rounded h-20"
                    />
                    <button className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 transition-colors">
                      Send Email
                    </button>
                  </form>
                </div>

                {/* SMS Notification */}
                <div className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center mb-3">
                    <Phone className="h-5 w-5 text-green-600 mr-2" />
                    <h3 className="font-medium">SMS Notification</h3>
                  </div>
                  <form className="space-y-3">
                    <select className="w-full p-2 border border-gray-300 rounded">
                      <option>Select Template</option>
                      <option>Status Update</option>
                      <option>Appointment Reminder</option>
                      <option>Document Collection</option>
                    </select>
                    <textarea
                      placeholder="SMS message (160 chars max)..."
                      className="w-full p-2 border border-gray-300 rounded h-20"
                      maxLength={160}
                    />
                    <button className="w-full bg-green-600 text-white py-2 rounded hover:bg-green-700 transition-colors">
                      Send SMS
                    </button>
                  </form>
                </div>

                {/* WhatsApp Notification */}
                <div className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center mb-3">
                    <MessageSquare className="h-5 w-5 text-green-600 mr-2" />
                    <h3 className="font-medium">WhatsApp Message</h3>
                  </div>
                  <form className="space-y-3">
                    <select className="w-full p-2 border border-gray-300 rounded">
                      <option>Select Template</option>
                      <option>Welcome Message</option>
                      <option>Status Update</option>
                      <option>Document Required</option>
                      <option>Collection Notice</option>
                    </select>
                    <textarea
                      placeholder="WhatsApp message..."
                      className="w-full p-2 border border-gray-300 rounded h-20"
                    />
                    <button className="w-full bg-green-500 text-white py-2 rounded hover:bg-green-600 transition-colors">
                      Send WhatsApp
                    </button>
                  </form>
                </div>
              </div>
            </div>

            {/* Public Announcements */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h2 className="text-lg font-semibold text-gray-800 mb-4">Public Announcements</h2>

              <form className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Announcement Title
                  </label>
                  <input
                    type="text"
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Enter announcement title..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Announcement Content
                  </label>
                  <textarea
                    className="w-full p-3 border border-gray-300 rounded-lg h-32 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Enter announcement content..."
                  />
                </div>

                <div className="flex gap-4">
                  <select className="p-3 border border-gray-300 rounded-lg">
                    <option>Priority Level</option>
                    <option>Low</option>
                    <option>Medium</option>
                    <option>High</option>
                    <option>Urgent</option>
                  </select>

                  <input
                    type="datetime-local"
                    className="p-3 border border-gray-300 rounded-lg"
                  />

                  <button className="px-6 py-3 bg-saffron text-white rounded-lg hover:bg-orange-600 transition-colors">
                    Publish Announcement
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Other tabs content would go here */}
        {activeTab !== 'applications' && activeTab !== 'notifications' && (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8 text-center">
            <div className="text-gray-400 mb-4">
              <Settings className="h-16 w-16 mx-auto" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} Module
            </h3>
            <p className="text-gray-600">
              This module is under development. Please check back later.
            </p>
          </div>
        )}
      </div>
    </div>
  )
}

export default AdminPanel
