'use client'

import React from 'react'
import Link from 'next/link'
import {
  FileText,
  BookOpen,
  Globe,
  GraduationCap,
  Briefcase,
  Users,
  Shield,
  Award,
  Heart,
  FileCheck,
  Clock,
  ArrowRight
} from 'lucide-react'

const Services = () => {
  const services = [
    {
      category: "Visa Services",
      icon: <Globe className="h-8 w-8" />,
      color: "bg-green-500",
      services: [
        { name: "E-Visa Information", href: "/apply/", processingTime: "3-5 days" },
        { name: "Manual Visa Form", href: "/apply/", processingTime: "7-15 days" },
        { name: "General Visa Instructions", href: "/apply/", processingTime: "N/A" },
        { name: "Visa Application Form", href: "/apply/", processingTime: "7-15 days" },
        { name: "Visa Fee Information", href: "/apply/", processingTime: "N/A" },
        { name: "Applications Sent by Courier/Post", href: "/apply/", processingTime: "10-20 days" },
        { name: "Collection Procedures", href: "/apply/", processingTime: "N/A" },
        { name: "Online Visa Application (Q&A)", href: "/apply/", processingTime: "N/A" },
        { name: "Types of Visas and Requirements", href: "/apply/", processingTime: "N/A" },
        { name: "Mandatory Biometric Enrolment", href: "/apply/", processingTime: "N/A" },
        { name: "Advisory regarding fraudulent e-visa", href: "/apply/", processingTime: "N/A" },
        { name: "Tourist Visa", href: "/apply/", processingTime: "7-15 days" },
        { name: "Business Visa", href: "/apply/", processingTime: "7-15 days" },
        { name: "Student Visa", href: "/apply/", processingTime: "10-15 days" },
        { name: "Medical Visa", href: "/apply/", processingTime: "5-10 days" },
        { name: "Conference Visa", href: "/apply/", processingTime: "7-15 days" }
      ]
    },
    {
      category: "Passport Services",
      icon: <BookOpen className="h-8 w-8" />,
      color: "bg-blue-500",
      services: [
        { name: "Requirements for Indian Nationals", href: "/apply/", processingTime: "N/A" },
        { name: "ICWF (Indian Community Welfare Fund)", href: "/apply/", processingTime: "N/A" },
        { name: "Passport FAQs", href: "/apply/", processingTime: "N/A" },
        { name: "Passport Application Status", href: "/track/", processingTime: "N/A" },
        { name: "New Passport Rules Announcement", href: "/apply/", processingTime: "N/A" },
        { name: "Photograph Requirements Guide", href: "/apply/", processingTime: "N/A" },
        { name: "General Guidelines for Applicants", href: "/apply/", processingTime: "N/A" },
        { name: "Re-issue of Passport (Lost/Stolen)", href: "/apply/", processingTime: "5-7 days" },
        { name: "Re-issue of Passport (Minor Child)", href: "/apply/", processingTime: "5-7 days" },
        { name: "Change of Name/Particulars", href: "/apply/", processingTime: "7-10 days" },
        { name: "Exhaustion of Pages / Damaged Passport", href: "/apply/", processingTime: "5-7 days" },
        { name: "Fresh Passport for Minor", href: "/apply/", processingTime: "7-10 days" },
        { name: "Passport Renewal", href: "/apply/", processingTime: "5-7 days" }
      ]
    },
    {
      category: "OCI/PIO Services",
      icon: <Users className="h-8 w-8" />,
      color: "bg-purple-500",
      services: [
        { name: "OCI (Overseas Citizen of India) Information", href: "/apply/", processingTime: "N/A" },
        { name: "PIO (Person of Indian Origin) Information", href: "/apply/", processingTime: "N/A" },
        { name: "Conversion of PIO into OCI", href: "/apply/", processingTime: "6-8 weeks" },
        { name: "New OCI Application", href: "/apply/", processingTime: "8-12 weeks" },
        { name: "OCI Misc (change of passport, name, etc.)", href: "/apply/", processingTime: "4-6 weeks" },
        { name: "OCI Damage / Loss", href: "/apply/", processingTime: "6-8 weeks" },
        { name: "OCI Renewal", href: "/apply/", processingTime: "6-8 weeks" },
        { name: "OCI Registration Certificate", href: "/apply/", processingTime: "8-12 weeks" }
      ]
    },
    {
      category: "Document Attestation",
      icon: <Award className="h-8 w-8" />,
      color: "bg-orange-500",
      services: [
        { name: "Attestation of Academic Degrees", href: "/apply/", processingTime: "5-7 days" },
        { name: "Attestation of Documents (General)", href: "/apply/", processingTime: "5-7 days" },
        { name: "Attestation of GPA by Foreigner", href: "/apply/", processingTime: "5-7 days" },
        { name: "Attestation of GPA by Indian Passport Holder", href: "/apply/", processingTime: "5-7 days" },
        { name: "Verification / Attestation of Indian DL", href: "/apply/", processingTime: "5-7 days" },
        { name: "Commercial Document Attestation", href: "/apply/", processingTime: "5-7 days" },
        { name: "Marriage Certificate Attestation", href: "/apply/", processingTime: "5-7 days" },
        { name: "Birth Certificate Attestation", href: "/apply/", processingTime: "5-7 days" }
      ]
    },
    {
      category: "Birth/Death Related Services",
      icon: <FileCheck className="h-8 w-8" />,
      color: "bg-red-500",
      services: [
        { name: "Birth Certificate Procedures", href: "/apply/", processingTime: "5-7 days" },
        { name: "Death Case Related Procedure", href: "/apply/", processingTime: "5-7 days" },
        { name: "Birth Certificate", href: "/apply/", processingTime: "5-7 days" },
        { name: "Unabridged Birth Certificate", href: "/apply/", processingTime: "5-7 days" },
        { name: "Death Certificate/Procedure", href: "/apply/", processingTime: "5-7 days" },
        { name: "Child Birth Registration", href: "/apply/", processingTime: "5-7 days" },
        { name: "Birth Registration for NRI Children", href: "/apply/", processingTime: "7-10 days" }
      ]
    },
    {
      category: "Miscellaneous Services",
      icon: <Shield className="h-8 w-8" />,
      color: "bg-indigo-500",
      services: [
        { name: "NOC for Child Passport in India", href: "/apply/", processingTime: "5-7 days" },
        { name: "Tracing the Roots Programme", href: "/apply/", processingTime: "10-15 days" },
        { name: "Registration of NRIs/PIOs/OCIs", href: "/apply/", processingTime: "7-10 days" },
        { name: "FAQs on Marital Disputes", href: "/apply/", processingTime: "N/A" },
        { name: "For Indian nationals on short term visa in SA", href: "/apply/", processingTime: "5-7 days" },
        { name: "Emergency Certificate", href: "/apply/", processingTime: "1-2 days" },
        { name: "Power of Attorney", href: "/apply/", processingTime: "5-7 days" },
        { name: "One and the Same Certificate", href: "/apply/", processingTime: "5-7 days" },
        { name: "NRI Certificate", href: "/apply/", processingTime: "5-7 days" },
        { name: "No Criminal Record Certificate", href: "/apply/", processingTime: "7-10 days" },
        { name: "Surrender Certificate", href: "/apply/", processingTime: "5-7 days" }
      ]
    }
  ]

  return (
    <section className="py-20 bg-gradient-to-br from-blue-50 to-indigo-100 relative">
      {/* Background pattern */}
      <div className="absolute inset-0 temple-pattern opacity-30"></div>

      <div className="relative z-10 container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16 animate-fadeInUp">
          <h2 className="text-4xl md:text-5xl font-bold text-navy mb-6">
            Our <span className="text-saffron">Consular Services</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
            Comprehensive consular services for Indian nationals and foreign citizens seeking Indian services.
            All services are processed with the highest standards of security and authenticity.
          </p>
          <div className="w-24 h-1 bg-saffron mx-auto rounded-full"></div>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-8 mb-16">
          {services.map((category, index) => (
            <div
              key={category.category}
              className="service-card rounded-xl p-8 shadow-lg animate-fadeInUp"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Category Header */}
              <div className="flex items-center mb-6">
                <div className={`${category.color} text-white p-3 rounded-lg mr-4 shadow-md`}>
                  {category.icon}
                </div>
                <h3 className="text-xl font-bold text-navy">{category.category}</h3>
              </div>

              {/* Services List */}
              <div className="space-y-4">
                {category.services.map((service, serviceIndex) => (
                  <Link
                    key={serviceIndex}
                    href={service.href}
                    className="block group"
                  >
                    <div className="flex items-center justify-between p-4 rounded-lg border border-gray-200 hover:border-saffron hover:bg-orange-50 transition-all duration-300">
                      <div className="flex-1">
                        <h4 className="text-sm font-medium text-gray-800 group-hover:text-navy transition-colors">
                          {service.name}
                        </h4>
                        <div className="flex items-center mt-1">
                          <Clock className="h-3 w-3 text-gray-400 mr-1" />
                          <span className="text-xs text-gray-500">{service.processingTime}</span>
                        </div>
                      </div>
                      <ArrowRight className="h-4 w-4 text-gray-400 group-hover:text-saffron transition-colors" />
                    </div>
                  </Link>
                ))}
              </div>

              {/* View All Link */}
              <Link
                href={`/services/${category.category.toLowerCase().replace(/\s+/g, '-')}`}
                className="mt-6 inline-flex items-center text-saffron hover:text-orange-600 font-medium transition-colors"
              >
                View All {category.category}
                <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </div>
          ))}
        </div>

        {/* Process Steps */}
        <div className="bg-white rounded-2xl p-8 shadow-lg animate-fadeInUp">
          <h3 className="text-2xl font-bold text-navy text-center mb-8">
            Simple <span className="text-saffron">Application Process</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
            {[
              { step: "1", title: "Choose Service", desc: "Select your required consular service" },
              { step: "2", title: "Fill Application", desc: "Complete the online application form" },
              { step: "3", title: "Upload Documents", desc: "Upload required supporting documents" },
              { step: "4", title: "Book Appointment", desc: "Schedule your visit to submit documents" },
              { step: "5", title: "Track & Collect", desc: "Track status and collect your documents" }
            ].map((item, index) => (
              <div key={index} className="text-center relative">
                {index < 4 && (
                  <div className="hidden md:block absolute top-6 left-full w-full h-0.5 bg-gradient-to-r from-saffron to-orange-400"></div>
                )}
                <div className="w-12 h-12 bg-saffron text-white rounded-full flex items-center justify-center font-bold text-lg mx-auto mb-4 shadow-lg">
                  {item.step}
                </div>
                <h4 className="font-semibold text-navy mb-2">{item.title}</h4>
                <p className="text-sm text-gray-600">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center mt-16 animate-fadeInUp">
          <p className="text-lg text-gray-600 mb-8">
            Ready to start your application? Get started today with our secure online system.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/apply"
              className="inline-flex items-center px-8 py-4 bg-saffron hover:bg-orange-600 text-white font-semibold rounded-lg shadow-lg transition-all duration-300 transform hover:scale-105"
            >
              Start Application
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
            <Link
              href="/services"
              className="inline-flex items-center px-8 py-4 border-2 border-navy text-navy hover:bg-navy hover:text-white font-semibold rounded-lg transition-all duration-300"
            >
              View All Services
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Services
